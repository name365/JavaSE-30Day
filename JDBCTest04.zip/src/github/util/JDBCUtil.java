package github.util;
/*
 * 操作JDBC的工具类
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCUtil {

	
	private static JDBCUtil instace = null;
	private static Properties pro = null;
	static{
		try {
			pro = new Properties();
			//读取配置文件
			pro.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("git.properties"));
			Class.forName(pro.getProperty("jdbc.driver"));
			instace = new JDBCUtil();//创建对象
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * 获取jdbcutil的对象
	 */
	public static JDBCUtil getInstance(){
		return instace;
	}
	
	//2.获取连接
	public Connection getConnection() throws SQLException{
		return DriverManager.getConnection(pro.getProperty("jdbc.url"),pro.getProperty("jdbc.username"),pro.getProperty("jdbc.password"));
	}
	
	//3.关闭
	public void close(ResultSet rs,Statement st,Connection connection){
		try {
			if(rs!=null){
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(st!=null){
					st.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				try {
					if(connection!=null){
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
