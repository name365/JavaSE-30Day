package github.test;

import java.util.List;

import org.junit.Test;

import github.dao.IProductDao;
import github.dao.impl.ProductDaoImpl;
import github.domain.Product;

public class JDBCTest {

	/*
	 * 删除数据
	 */
	IProductDao productDao = new ProductDaoImpl();
	@Test
	public void test() {
		productDao.deleteProductById(2);
	}

	/*
	 * 更改数据
	 */
	@Test
	public void testUpdate() {
		Product p1 = new Product();
		
		p1.setProductName("荧光闪烁");
		p1.setId(14);
		
		productDao.updateProduct(p1);
	}
	
	/*
	 * 单查询
	 */
	@Test
	public void testQuery() {
		Product p = productDao.queryProductById(22L);
		System.out.println(p);
	}
	
	/*
	 * 多查询
	 */
	@Test
	public void testAllQuery() {
		List<Product> queryAllProduct = productDao.queryAllProduct();
		for(Product p : queryAllProduct){
			System.out.println(p);
		}	
	}
	
	/*
	 * 增加数据
	 */
	@Test
	public void addProductTest() {
		Product p1 = new Product();
		
		p1.setId(5);
		p1.setProductName("荧光闪烁");
		p1.setDir_id(5);
		p1.setSalePrice(186.32);
		p1.setSupplier("可乐");
		p1.setBrand("可乐");
		p1.setCutoff(0.72);
		p1.setCostPrice(143.52);
		
		productDao.addProduct(p1);
	}
}
