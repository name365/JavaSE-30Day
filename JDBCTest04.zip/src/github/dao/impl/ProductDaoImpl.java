package github.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import github.dao.IProductDao;
import github.domain.Product;
import github.util.JDBCUtil;

public class ProductDaoImpl implements IProductDao {

JDBCUtil jdbc = JDBCUtil.getInstance();
	
	@Override
	public void deleteProductById(long id) {
		Connection connection = null;
		PreparedStatement pst = null;
		try {
			connection = jdbc.getConnection();
			pst = connection.prepareStatement("delete from product where id = ?");
			pst.setLong(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			jdbc.close(null, pst, connection);
		}
	}

	@Override
	public void updateProduct(Product product) {
		Connection connection = null;
		PreparedStatement pst = null;
		try {
			connection = jdbc.getConnection();
			pst = connection.prepareStatement("update product set productName = ? where id = ?");
			pst.setString(1, product.getProductName());
			pst.setLong(2, product.getId());
			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			jdbc.close(null, pst, connection);
		}
	}

	@Override
	public Product queryProductById(long id) {
		Product p1 = new Product();
		Connection connection = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			connection = jdbc.getConnection();
			pst = connection.prepareStatement("select * from product where id = ?");
			pst.setLong(1, id);
			rs = pst.executeQuery();
			while(rs.next()){
				String productName = rs.getString("productName");
				p1.setProductName(productName);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			jdbc.close(rs, pst, connection);
		}
		return p1;
	}

	@Override
	public List<Product> queryAllProduct() {
		List<Product> list = new ArrayList<Product>();
		try {
			Connection connection = jdbc.getConnection();
			PreparedStatement pst = connection.prepareStatement("select * from product");
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				long id = rs.getLong("id");
				String productName = rs.getString("productName");
				long dir_id = rs.getLong("dir_id");
				double salePrice = rs.getDouble("salePrice");
				String supplier = rs.getString("supplier");
				String brand = rs.getString("brand");
				double cutoff = rs.getDouble("cutoff");
				double costPrice = rs.getDouble("costPrice");
				Product p = new Product(id, productName, dir_id, salePrice, supplier, brand, cutoff, costPrice);
				list.add(p);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return list;
	}

	@Override
	public void addProduct(Product product) {
        String sql="insert into product (id,productName,dir_id,salePrice,supplier,brand,cutoff,costPrice) values(?,?,?,?,?,?,?,?)";
		Connection connection = null;
		PreparedStatement pst = null;
		try {
			connection = jdbc.getConnection();
			
			pst = connection.prepareStatement(sql);
			pst.setLong(1, product.getId());
			pst.setString(2, product.getProductName());
			pst.setLong(3, product.getDir_id());
			pst.setDouble(4, product.getSalePrice());
			pst.setString(5,product.getSupplier());
			pst.setString(6, product.getBrand());
			pst.setDouble(7, product.getCutoff());
			pst.setDouble(8, product.getCostPrice());
			
			pst.executeUpdate();
		}  catch (SQLException e) {
			e.printStackTrace();
		}finally{
			jdbc.close(null, pst, connection);
		}
	}
}
