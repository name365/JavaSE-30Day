package github.dao;

import java.util.List;

import github.domain.Product;

public interface IProductDao {

	/*
	 * 根据id删除产品
	 */
	public void deleteProductById(long id);
	
	/*
	 * 更新数据的操作
	 */
	public void updateProduct(Product product);

	/*
	 * 查询数据的操作,根据id
	 */
	public Product queryProductById(long id);

	/*
	 * 查询所有的产品
	 */
	public List<Product> queryAllProduct();

	/*
	 * 新增数据
	 */
	public void addProduct(Product product);

}
